©2011 Floodfonts, designed by Felix Braden.

AQUARIUS is freeware! You are allowed to use the font(s) for every kind of publication (electronic/print), it doesn't matter if its commercial or not. You can copy and give it away to your friends as long as the README-file is included with the opentype or truetype data. 

It may not be sold, redesigned or offered for download without permission of the designer.

I am looking forward to your comments, suggestions and to any information if/how you incorporated this font.

AQUARIUS works best with a font size of 8 pixels.



http://www.floodfonts.com
http://twitter.com/floodfonts
https://www.instagram.com/floodfonts
https://www.behance.net/floodfonts
info@felixbraden.de